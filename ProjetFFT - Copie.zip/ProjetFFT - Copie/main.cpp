#include "mbed.h"
#include "Grove_LCD_RGB_Backlight.h"
#include <math.h> 
#include <cstdio>

void initLCD();
void write_command(char c);
void write_data(char c);
void print_LCD_char(char c);
void print_LCD_String(char *s);
void initLED();
void configLED(char b, char g, char r, char a);
void print_LCD_int(int en);
char* itoa(int i, char b[]);

//PwmOut e1(P2_5);
//DigitalOut d1(P0_0);
AnalogIn micro(A0);
I2C i2c(I2C_SDA , I2C_SCL );
Serial pc(USBTX, USBRX);


int LCD_addr = 0x7C;
int LED_addr = 0xC4;
int i = 0;
char*str;
char ch[36];

float e = 2.7182818284590452353602874713526624977572470936999595749669676277240766303535475945713821785251664274;
float pi = 3.141592653589793238462643383279502884;

float r = 0.5;
int rtoint = (int)(r*10);

void initLED(){
    
    char cmd[3];
    wait(0.04);
    cmd[0] = 0x80;
    cmd[1] = 0x00;
    cmd[2] = 0x00;
    i2c.write(LED_addr, cmd, 3, false);
    cmd[0] = 0x08;
    cmd[1] = 0xAA;
    i2c.write(LED_addr, cmd, 2, false);
}

void configLED(char b, char g, char r, char a){
    
    char cmd[5];
    cmd[0] = 0xA2;
    cmd[1] = b;
    cmd[2] = g;
    cmd[3] = r;
    cmd[4] = a;
    i2c.write(LED_addr, cmd, 5, false);
    
}
    

void initLCD(){
    wait(0.04);
    write_command(0x3C);//4 pour mode 1 ligne(Celle du haut), C pour 2
    write_command(0x0C);
    write_command(0x01);
    wait(0.0016);
    write_command(0x06);
    
    
}

void write_command(char c){
    char cmd[2];
    cmd[0] = 0x80;
    cmd[1] = c;
    i2c.write(LCD_addr, cmd, 2, false);//false car répété
}

void write_data(char c){
    char cmd[2];
    cmd[0] = 0x40;
    cmd[1] = c;
    i2c.write(LCD_addr, cmd, 2, false);
}

void print_LCD_char(char c){
    char cmd[2];
    cmd[0] = 0x40;
    cmd[1] = c;
    i2c.write(LCD_addr, cmd, 2, false);
}

void print_LCD_String(char *s){
    char cmd[36];
    cmd[0] = 0x40;
    for(int n = 1; n < strlen(s)+1; n++){
        cmd[n] = s[n-1];
    }
    
    
    i2c.write(LCD_addr, cmd, strlen(s)+1, false);
}

void affichage(char n, char* b){
		wait(0.4);
		write_command(0x01);
		wait(0.00153);
		sprintf(b, "%d", n);
		print_LCD_String(b);
}

 
int main() {
	
	initLED();
  configLED(0xFF, 0xFF, 0xFF, 0xFF);
	initLCD();
	
	int nbEch = 1000; //nombre d'échantillons
	int nbFreq = 1000;
	char buffer[50];
	float echantillons[nbEch];
	int cpt = 0;
  float n;
	float TFDT[nbFreq];
	float Re[nbFreq];
	float Im[nbFreq];
	int continuer = 1;
	
	//FILE* Sortie = fopen("yourtext.txt", "w");
			//fprintf(Sortie,"Top 5 programming language\n");
			//fclose(Sortie);
	//pc.printf("I got");
  
	while(continuer){
		
		//pc.printf("%d    ",cpt);
		
        //pc.printf("Loudness: %f\r\n", micro.read());
        //wait(0.5);
		
		//n = 0;
		//(char)255*micro.read();
		//wait(0.0001);//Freq d'échantillonnage
		//affichage(n, buffer);
		/*if (cpt > 100)
			n = -150;
		
		if (cpt > 200)
			n = 150;
		
		if (cpt > 300)
			n = -150;
		
		if (cpt > 400)
			n = 150;*/
			//n = cos((float)cpt/10);
			//cpt = cpt+1;
			//pc.printf("   %f",n);
			n = 100.0;
		
		
		
		if (cpt < nbEch){
			pc.printf("   AAA   ");
			echantillons[cpt] = n;
			cpt = cpt + 1;
		}
		
		else {
			pc.printf("   BBB   ");
			continuer = 0;
			
			for (int i = 0; i < nbEch-1; i++){
				echantillons[i] = echantillons[i+1];
				echantillons[nbEch-1] = n;
			}
			
			for (int freq = 0; freq < nbFreq; freq++){
				TFDT[freq] = 0.0;
				Re[freq] = 0.0;
				Im[freq] = 0.0;
				
				for (int i = 0; i < nbEch; i++){//Separer reels et im
					Re[freq] = Re[freq] + echantillons[i]*cos(2*pi*i*freq/nbEch);
					Im[freq] = Im[freq] - echantillons[i]*sin(2*pi*i*freq/nbEch);
				}
				
				TFDT[freq] = sqrt(Re[freq]*Re[freq]+Im[freq]*Im[freq]);
				 
				
			}
			
			float max = 0.0;
			int maxind = 0;
			
			for (int i = 0; i < nbFreq; i++){
				if (TFDT[i] > max){
					max = TFDT[i];
					maxind = i*20;
				}
				pc.printf("f = %d -- A = %f",i*20,TFDT[i]);
				pc.printf("\r\n");
			}
			pc.printf("   Frequence dominante = %d Hz   ", maxind);
			
		}
		
		
		
		
		
		
		
	}
		
}